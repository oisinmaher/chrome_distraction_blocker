Download and extract file, upload file to chrome extension and done.
Blocks youtube home page, youtube shorts, subscriptions page.
Hides the recommended section side bar on videos
Redirects to google.com for, facebook, tiktok, instagram, x (twitter)
